exercise 1 - seam carving

submitting: Ofir Ventura 201085958
			Yana Tartakovsky 306762279
			
horizontal seam vs. vertical seam bonus was implemented
also special picture bonus was done.