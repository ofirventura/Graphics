import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;


public class Main {

	public static void main(String[] args) throws IOException {
		
		//TODO: argument check
		String input = args[0];
		int newHeight = Integer.parseInt(args[2]);
		int newWidth =  Integer.parseInt(args[1]); // TODO : lahafoch
		int energy =  Integer.parseInt(args[3]);
		String outputPath = args[4];
		
		//int lastIndex = input.lastIndexOf('.');
		
		
		//String output = outputPath + (lastIndex == -1 ? input : input.substring(lastIndex));
		//System.out.println(output);
		
		BufferedImage img = ImageIO.read(new File(input));

		SeamCarving s = new SeamCarving(img, newWidth, newHeight,energy, outputPath);

		s.Seam();
		//double[][] a = s.calcMapEntropy();
/*
		int n = a.length;
		int m = a[a.length-1].length;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				img.setRGB(j, i, ((int)a[i][j]) | ((int)a[i][j] << 8) | ((int)a[i][j] << 16));
			}
		}

		File outputfile = new File("image_entropy.bmp");
		ImageIO.write(img, "BMP", outputfile);
		*/
		//BufferedImage img2 = ImageIO.read(new File(input));
		//SeamCarving s2 = new SeamCarving(img2);
		/*double[][] b = s2.calcMapGradient();
		int k = a.length;
		int l = a[a.length-1].length;
		for (int i = 0; i < k; i++) {

//		File outputfile = new File("image_entropy.jpg");
		ImageIO.write(img, "jpg", outputfile);
		
		//BufferedImage img2 = ImageIO.read(new File(input));
		//SeamCarving s2 = new SeamCarving(img2,newWidth, newHeight, energy);
		//double[][] b = s2.calcMapGradient();
		//s2.Seam();
		//int k = b.length;
		//int l = b[b.length-1].length;
		/*for (int i = 0; i < k; i++) {
>>>>>>> 50e53915f6f9f918e7f1e7498988a7969c280101
			for (int j = 0; j < l; j++) {
				//System.out.print(a[i][j] + " ");
				img2.setRGB(i, j, ((int)b[i][j]) | ((int)b[i][j] << 8) | ((int)b[i][j] << 16));
			}
			//System.out.println("\n");
<<<<<<< HEAD
		}
		File outputfile2 = new File("image_gradiant.bmp");
		ImageIO.write(img2, "BMP", outputfile2);
=======
		}*/
		//File outputfile2 = new File("image_output.jpg");
		//ImageIO.write(img2, "jpg", outputfile2);

	}
	
}
